<?php
require_once 'includes/header.php';
if (!isLoggedIn()) { redirect('login.php'); }

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

$tasks = [
    'assigned' => [],
    'due_soon' => [], // e.g., within 3 days
    'overdue' => []
];

// Fetch assignments for the To-Do list
if ($user_role == 'student') {
    $stmt = $conn->prepare("
        SELECT a.id as assignment_id, a.title, a.due_date, c.id as class_id, c.class_name
        FROM assignments a
        JOIN classes c ON a.class_id = c.id
        JOIN enrollments e ON c.id = e.class_id
        WHERE e.user_id = ? AND 
              NOT EXISTS (SELECT 1 FROM submissions s WHERE s.assignment_id = a.id AND s.student_id = ?)
        ORDER BY a.due_date ASC
    ");
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $due_timestamp = strtotime($row['due_date']);
        $now_timestamp = time();
        $days_to_due = ($due_timestamp - $now_timestamp) / (60 * 60 * 24); // Difference in days

        $task_item = [
            'id' => 'assignment-' . $row['assignment_id'],
            'title' => $row['title'],
            'due_date' => $row['due_date'],
            'class_name' => $row['class_name'],
            'link' => 'submit_assignment.php?assignment_id=' . $row['assignment_id']
        ];

        if ($due_timestamp < $now_timestamp) {
            $tasks['overdue'][] = $task_item;
        } elseif ($days_to_due <= 3) { // Due within 3 days (inclusive of today if due later today)
            $tasks['due_soon'][] = $task_item;
        } else {
            $tasks['assigned'][] = $task_item;
        }
    }
    $stmt->close();
} else { // Teacher - tasks are assignments needing grading
    $stmt = $conn->prepare("
        SELECT a.id as assignment_id, a.title, a.due_date, c.class_name, c.id as class_id,
               (SELECT COUNT(*) FROM submissions s WHERE s.assignment_id = a.id AND (s.status = 'submitted' OR s.status = 'late' OR s.status = 'pending_grading')) as pending_grades_count
        FROM assignments a
        JOIN classes c ON a.class_id = c.id
        WHERE c.teacher_id = ?
        HAVING pending_grades_count > 0
        ORDER BY a.due_date DESC -- Show most recently due/overdue first for grading
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
     while ($row = $result->fetch_assoc()) {
        $due_timestamp = strtotime($row['due_date']);
        $now_timestamp = time();

        $task_item = [
            'id' => 'grade-assignment-' . $row['assignment_id'],
            'title' => 'Chấm bài: ' . $row['title'] . ' ('. $row['pending_grades_count'] .' bài chờ)',
            'due_date' => $row['due_date'], 
            'class_name' => $row['class_name'],
            'link' => 'view_submissions.php?assignment_id=' . $row['assignment_id']
        ];
        
        if ($due_timestamp < $now_timestamp) { // Assignment due date has passed
             $tasks['overdue'][] = $task_item; // Categorize as "Overdue" for teacher's grading (meaning assignment itself is past due)
        } elseif ( ($due_timestamp - $now_timestamp) / (60 * 60 * 24) <= 3 ) { // Due soon
            $tasks['due_soon'][] = $task_item;
        } else { // Assigned, not yet due soon
            $tasks['assigned'][] = $task_item;
        }
    }
    $stmt->close();
}

?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2><i class="bi bi-list-check me-2"></i>Việc cần làm</h2>
    <!-- Add filters or "Add new task" button if implementing personal tasks -->
</div>

<?php if (empty($tasks['assigned']) && empty($tasks['due_soon']) && empty($tasks['overdue']) ): ?>
     <div class="alert alert-success">
        <?php if ($user_role == 'teacher'): ?>
            <i class="bi bi-clipboard-check-fill me-2"></i>Hiện tại không có bài tập nào cần chấm điểm.
        <?php else: ?>
            <i class="bi bi-emoji-smile-fill me-2"></i>Tuyệt vời! Bạn không có bài tập nào cần hoàn thành.
        <?php endif; ?>
     </div>
<?php endif; ?>


<?php
function render_task_list_section($task_list, $title, $icon_class, $list_class_modifier = '') {
    if (!empty($task_list)) {
        echo "<h4 class='mt-4 mb-3'><i class='{$icon_class} me-2'></i>{$title} <span class='badge bg-secondary'>".count($task_list)."</span></h4>";
        echo '<ul class="list-group shadow-sm">';
        foreach ($task_list as $task) {
            echo '<li class="list-group-item d-flex justify-content-between align-items-center ' . $list_class_modifier . '">';
            echo '<div>';
            echo '<strong><a href="' . htmlspecialchars($task['link']) . '" class="text-decoration-none">' . htmlspecialchars($task['title']) . '</a></strong><br>';
            echo '<small class="text-muted">Lớp: ' . htmlspecialchars($task['class_name']) . ' | Hạn: ' . date("d/m/Y H:i", strtotime($task['due_date'])) . '</small>';
            echo '</div>';
            echo '<a href="' . htmlspecialchars($task['link']) . '" class="btn btn-sm btn-outline-primary">Xem</a>';
            echo '</li>';
        }
        echo '</ul>';
    }
}

render_task_list_section($tasks['overdue'], $user_role == 'student' ? 'Quá hạn' : 'Cần chấm (Bài đã qua hạn)', 'bi bi-exclamation-octagon-fill text-danger', 'list-group-item-danger');
render_task_list_section($tasks['due_soon'], $user_role == 'student' ? 'Sắp đến hạn (trong 3 ngày)' : 'Cần chấm (Bài sắp đến hạn)', 'bi bi-alarm-fill text-warning', 'list-group-item-warning');
render_task_list_section($tasks['assigned'], $user_role == 'student' ? 'Đã giao (Chưa đến hạn sớm)' : 'Cần chấm (Bài đã giao)', 'bi bi-journal-arrow-down text-info');

?>
<!-- Placeholder for adding personal tasks if desired -->
<!--
<div class="mt-5 card shadow-sm">
    <div class="card-header">
        <h4 class="mb-0">Thêm công việc cá nhân (Tính năng đang phát triển)</h4>
    </div>
    <div class="card-body">
        <form>
            <div class="mb-3">
                <label for="personal_task_title" class="form-label">Tiêu đề công việc</label>
                <input type="text" class="form-control" id="personal_task_title" disabled>
            </div>
            <button type="submit" class="btn btn-info" disabled>Thêm công việc</button>
        </form>
    </div>
</div>
-->

<?php require_once 'includes/footer.php'; ?>