<?php
require_once 'includes/header.php';
if (!isLoggedIn() || !isStudent()) {
    $_SESSION['message'] = "Chỉ học sinh mới có thể tham gia lớp học.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}

$class_code = '';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_code = trim(strtoupper($_POST['class_code']));
    $user_id = $_SESSION['user_id'];

    if (empty($class_code)) {
        $errors['class_code'] = "Mã lớp là bắt buộc.";
    }

    if (empty($errors)) {
        // Find class by code
        $stmt = $conn->prepare("SELECT id, class_name FROM classes WHERE class_code = ?");
        $stmt->bind_param("s", $class_code);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $class = $result->fetch_assoc();
            $class_id = $class['id'];
            $class_name_joined = $class['class_name'];

            // Check if already enrolled
            $stmt_check_enroll = $conn->prepare("SELECT id FROM enrollments WHERE user_id = ? AND class_id = ?");
            $stmt_check_enroll->bind_param("ii", $user_id, $class_id);
            $stmt_check_enroll->execute();
            $stmt_check_enroll->store_result();

            if ($stmt_check_enroll->num_rows > 0) {
                $errors['class_code'] = "Bạn đã tham gia lớp học \"".htmlspecialchars($class_name_joined)."\" rồi.";
            } else {
                // Enroll student
                $stmt_enroll = $conn->prepare("INSERT INTO enrollments (user_id, class_id) VALUES (?, ?)");
                $stmt_enroll->bind_param("ii", $user_id, $class_id);
                if ($stmt_enroll->execute()) {
                    $_SESSION['message'] = "Tham gia lớp học \"".htmlspecialchars($class_name_joined)."\" thành công!";
                    $_SESSION['message_type'] = "success";
                    redirect('class_view.php?id=' . $class_id);
                } else {
                    $errors['db_error'] = "Lỗi khi tham gia lớp học: " . $stmt_enroll->error;
                }
                $stmt_enroll->close();
            }
            $stmt_check_enroll->close();
        } else {
            $errors['class_code'] = "Mã lớp không hợp lệ hoặc không tồn tại.";
        }
        $stmt->close();
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h3 class="mb-0">Tham gia lớp học</h3>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($errors['db_error'])): ?>
                    <div class="alert alert-danger"><?php echo $errors['db_error']; ?></div>
                <?php endif; ?>
                <form action="join_class.php" method="POST">
                    <div class="mb-3">
                        <label for="class_code" class="form-label">Nhập mã lớp <span class="text-danger">*</span></label>
                        <input type="text" class="form-control <?php echo isset($errors['class_code']) ? 'is-invalid' : ''; ?>" id="class_code" name="class_code" value="<?php echo htmlspecialchars($class_code); ?>" placeholder="VD: ABC123" style="text-transform:uppercase" required autofocus>
                        <?php if (isset($errors['class_code'])): ?><div class="invalid-feedback"><?php echo $errors['class_code']; ?></div><?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-box-arrow-in-right me-2"></i>Tham gia</button>
                    <a href="dashboard.php" class="btn btn-secondary">Hủy</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>