<?php
require_once 'includes/header.php';
if (!isLoggedIn() || !isStudent()) {
    $_SESSION['message'] = "Chỉ học sinh mới có thể nộp bài.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}

$assignment_id = isset($_GET['assignment_id']) ? (int)$_GET['assignment_id'] : 0;
if ($assignment_id <= 0) {
    $_SESSION['message'] = "ID bài tập không hợp lệ.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}

$student_id = $_SESSION['user_id'];

// Fetch assignment details and check if student is in the class of this assignment
$stmt_assign = $conn->prepare("
    SELECT a.*, c.id as class_id, c.class_name
    FROM assignments a
    JOIN classes c ON a.class_id = c.id
    JOIN enrollments e ON c.id = e.class_id
    WHERE a.id = ? AND e.user_id = ?
");
$stmt_assign->bind_param("ii", $assignment_id, $student_id);
$stmt_assign->execute();
$result_assign = $stmt_assign->get_result();
if ($result_assign->num_rows == 0) {
    $_SESSION['message'] = "Bài tập không tồn tại hoặc bạn không có quyền truy cập bài tập này.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php'); // Or back to class view
}
$assignment = $result_assign->fetch_assoc();
$stmt_assign->close();

// Check if already submitted
$existing_submission = null;
$stmt_check_sub = $conn->prepare("SELECT * FROM submissions WHERE assignment_id = ? AND student_id = ?");
$stmt_check_sub->bind_param("ii", $assignment_id, $student_id);
$stmt_check_sub->execute();
$result_check_sub = $stmt_check_sub->get_result();
if ($result_check_sub->num_rows > 0) {
    $existing_submission = $result_check_sub->fetch_assoc();
}
$stmt_check_sub->close();

$is_view_mode = isset($_GET['view']) && $_GET['view'] == '1' && $existing_submission;
$can_resubmit = false; // Add logic here if you want to allow resubmission, e.g., before due date or if teacher allows

$submission_text = $existing_submission['submission_text'] ?? '';
$errors = [];

// Determine if submission is allowed
$is_past_due = strtotime($assignment['due_date']) < time();
$submission_allowed = !$existing_submission || $can_resubmit;
if ($is_past_due && !$existing_submission) {
    // $submission_allowed = false; // Strict: no late submissions if not already submitted
    // Or allow late submissions:
    // $submission_allowed = true; // if policy allows late submissions
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && !$is_view_mode && $submission_allowed) {
    $submission_text = trim($_POST['submission_text']);
    $file_path = $existing_submission['file_path'] ?? null; // Keep existing file if not re-uploading

    // Basic validation: at least one field (text or file) must be provided for a new submission
    if (!$existing_submission && empty($submission_text) && (empty($_FILES['submission_file']) || $_FILES['submission_file']['error'] == UPLOAD_ERR_NO_FILE)) {
        $errors['submission'] = "Bạn phải nhập nội dung hoặc tải lên tệp.";
    }

    // File upload handling (only if a new file is provided)
    if (isset($_FILES['submission_file']) && $_FILES['submission_file']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/submission_files/';
        if (!is_dir($upload_dir)) {
             if (!mkdir($upload_dir, 0777, true) && !is_dir($upload_dir)) {
                 $errors['file'] = "Không thể tạo thư mục tải lên: " . $upload_dir;
            }
        }

        if(empty($errors['file'])) {
            $file_name = $student_id . '_' . time() . '_' . preg_replace("/[^a-zA-Z0-9.\-_]/", "_", basename($_FILES['submission_file']['name']));
            $target_file = $upload_dir . $file_name;
            $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

            if ($_FILES['submission_file']['size'] > 10000000) { // 10MB for submissions
                $errors['file'] = "Tệp quá lớn (tối đa 10MB).";
            }
            $allowed_types = ['pdf', 'doc', 'docx', 'txt', 'jpg', 'jpeg', 'png', 'zip', 'ppt', 'pptx', 'xls', 'xlsx'];
            if (!in_array($file_type, $allowed_types)) {
                $errors['file'] = "Loại tệp không được phép. (Cho phép: " . implode(', ', $allowed_types) . ")";
            }

            if (empty($errors['file'])) {
                // Delete old file if replacing
                if ($can_resubmit && $existing_submission && $existing_submission['file_path'] && file_exists($upload_dir . $existing_submission['file_path'])) {
                    // unlink($upload_dir . $existing_submission['file_path']); // Be careful with this, ensure user intends to replace
                }
                if (move_uploaded_file($_FILES['submission_file']['tmp_name'], $target_file)) {
                    $file_path = $file_name; // New file path
                } else {
                    $errors['file'] = "Lỗi khi tải tệp nộp bài. Error code: ".$_FILES['submission_file']['error'];
                }
            }
        }
    } elseif (isset($_FILES['submission_file']) && $_FILES['submission_file']['error'] != UPLOAD_ERR_NO_FILE) {
         $errors['file'] = "Lỗi tải tệp lên. Mã lỗi: " . $_FILES['submission_file']['error'];
    }


    if (empty($errors)) {
        $status = 'submitted';
        if (strtotime($assignment['due_date']) < time() && (!$existing_submission || $existing_submission['status'] != 'late') ) { // Only mark as late if it's a new submission past due, or an update to a non-late one
            $status = 'late';
        } elseif ($existing_submission) {
            $status = $existing_submission['status']; // Keep existing status if just updating text/file before due
            if ($status == 'late' && strtotime($assignment['due_date']) >= time()) { // if due date was extended, and it was late.
                 // $status = 'submitted'; // This logic can get complex.
            }
        }


        if ($existing_submission && $can_resubmit) { // Update existing
            // $stmt_submit = $conn->prepare("UPDATE submissions SET submission_text = ?, file_path = ?, submitted_at = NOW(), status = ? WHERE id = ?");
            // $stmt_submit->bind_param("ssssi", $submission_text, $file_path, $status, $existing_submission['id']);
             $_SESSION['message'] = "Tính năng sửa bài nộp chưa được hỗ trợ đầy đủ trong bản demo này.";
             $_SESSION['message_type'] = "info";
             // For now, we prevent re-submission directly to keep it simple.
        } elseif (!$existing_submission) { // Insert new
            $stmt_submit = $conn->prepare("INSERT INTO submissions (assignment_id, student_id, submission_text, file_path, status, submitted_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt_submit->bind_param("iisss", $assignment_id, $student_id, $submission_text, $file_path, $status);

            if ($stmt_submit->execute()) {
                $_SESSION['message'] = "Nộp bài thành công!";
                $_SESSION['message_type'] = "success";
                redirect("class_view.php?id={$assignment['class_id']}&tab=assignments");
            } else {
                $errors['db_error'] = "Lỗi khi nộp bài: " . $stmt_submit->error;
            }
            $stmt_submit->close();
        }
    }
}
?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h3 class="mb-0"><?php echo $is_view_mode ? 'Bài nộp của bạn cho:' : 'Nộp bài cho:'; ?> <?php echo htmlspecialchars($assignment['title']); ?></h3>
                <p class="mb-0"><small>Lớp: <?php echo htmlspecialchars($assignment['class_name']); ?> | Hạn nộp: <span class="<?php echo $is_past_due ? 'text-warning fw-bold' : '';?>"><?php echo date("d/m/Y H:i", strtotime($assignment['due_date'])); ?> <?php if($is_past_due) echo "(Đã qua hạn)";?></span></small></p>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?><p class="mb-0"><?php echo $error; ?></p><?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($existing_submission && !$is_view_mode && !$can_resubmit): ?>
                     <div class="alert alert-info">
                        <h5 class="alert-heading">Bạn đã nộp bài!</h5>
                        <p>Bạn đã nộp bài cho bài tập này vào lúc <?php echo date("d/m/Y H:i", strtotime($existing_submission['submitted_at'])); ?>.</p>
                        <p>Trạng thái: <strong><?php echo htmlspecialchars(ucfirst($existing_submission['status'])); ?></strong>.</p>
                        <hr>
                        <p class="mb-0"><a href="submit_assignment.php?assignment_id=<?php echo $assignment_id; ?>&view=1" class="btn btn-info"><i class="bi bi-eye-fill me-1"></i>Xem chi tiết bài nộp</a></p>
                    </div>
                <?php elseif ($is_view_mode): ?>
                    <h4>Nội dung đã nộp:</h4>
                    <?php if (!empty($existing_submission['submission_text'])): ?>
                        <div class="p-3 bg-light border rounded mb-3">
                            <?php echo nl2br(htmlspecialchars($existing_submission['submission_text'])); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($existing_submission['file_path'])): ?>
                        <p><strong>Tệp đã nộp:</strong> <a href="uploads/submission_files/<?php echo htmlspecialchars($existing_submission['file_path']); ?>" target="_blank" download><i class="bi bi-download me-1"></i><?php echo htmlspecialchars($existing_submission['file_path']); ?></a></p>
                    <?php endif; ?>
                    <?php if (empty($existing_submission['submission_text']) && empty($existing_submission['file_path'])): ?>
                        <p class="text-muted">Không có nội dung hoặc tệp nào được nộp.</p>
                    <?php endif; ?>
                    <hr>
                    <p><strong>Nộp lúc:</strong> <?php echo date("d/m/Y H:i", strtotime($existing_submission['submitted_at'])); ?></p>
                    <p><strong>Trạng thái:</strong> <span class="badge bg-<?php 
                        if ($existing_submission['status'] == 'graded') echo 'success'; 
                        elseif ($existing_submission['status'] == 'late') echo 'warning text-dark'; 
                        else echo 'info text-dark'; 
                    ?>"><?php echo htmlspecialchars(ucfirst($existing_submission['status'])); ?></span></p>
                     <?php if ($existing_submission['grade']): ?>
                        <p><strong>Điểm:</strong> <span class="fw-bold fs-5 text-primary"><?php echo htmlspecialchars($existing_submission['grade']); ?></span></p>
                    <?php endif; ?>
                    <?php if ($existing_submission['feedback']): ?>
                        <p><strong>Phản hồi của giáo viên:</strong></p>
                        <div class="p-3 bg-light border rounded">
                            <?php echo nl2br(htmlspecialchars($existing_submission['feedback'])); ?>
                        </div>
                    <?php endif; ?>
                     <a href="class_view.php?id=<?php echo $assignment['class_id']; ?>&tab=assignments" class="btn btn-secondary mt-3"><i class="bi bi-arrow-left-circle me-1"></i>Quay lại</a>
                <?php elseif (!$submission_allowed && $is_past_due): ?>
                     <div class="alert alert-warning">
                        <h5 class="alert-heading">Đã quá hạn nộp!</h5>
                        <p>Rất tiếc, bạn không thể nộp bài cho bài tập này nữa vì đã quá thời gian quy định.</p>
                        <a href="class_view.php?id=<?php echo $assignment['class_id']; ?>&tab=assignments" class="btn btn-secondary mt-3"><i class="bi bi-arrow-left-circle me-1"></i>Quay lại</a>
                     </div>
                <?php else: // Form to submit or resubmit (if $can_resubmit is true) ?>
                    <?php if ($is_past_due && !$existing_submission): ?>
                        <div class="alert alert-warning"><strong>Lưu ý:</strong> Bạn đang nộp bài sau thời hạn quy định. Bài nộp có thể được đánh dấu là "Nộp muộn".</div>
                    <?php endif; ?>
                    <form action="submit_assignment.php?assignment_id=<?php echo $assignment_id; ?>" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="submission_text" class="form-label">Nội dung bài làm (nhập trực tiếp)</label>
                            <textarea class="form-control" id="submission_text" name="submission_text" rows="8"><?php echo htmlspecialchars($submission_text); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="submission_file" class="form-label">Hoặc tải lên tệp bài làm <?php if($existing_submission && $existing_submission['file_path']) echo "(Tệp hiện tại: ".htmlspecialchars($existing_submission['file_path']).")"; ?></label>
                            <input type="file" class="form-control" id="submission_file" name="submission_file">
                            <div class="form-text">Tối đa 10MB. Các định dạng phổ biến được chấp nhận.</div>
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-upload me-1"></i><?php echo ($existing_submission && $can_resubmit) ? 'Cập nhật bài nộp' : 'Nộp bài'; ?></button>
                        <a href="class_view.php?id=<?php echo $assignment['class_id']; ?>&tab=assignments" class="btn btn-secondary">Hủy</a>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>