<?php
require_once 'includes/header.php';
if (!isLoggedIn()) { redirect('login.php'); }

$class_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($class_id <= 0) {
    $_SESSION['message'] = "ID lớp học không hợp lệ.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}

// Check if user is enrolled or is the teacher of this class
$user_id = $_SESSION['user_id'];
$is_teacher_of_class = false;
$is_enrolled = false;

$stmt_class = $conn->prepare("SELECT c.*, u.full_name as teacher_name FROM classes c JOIN users u ON c.teacher_id = u.id WHERE c.id = ?");
$stmt_class->bind_param("i", $class_id);
$stmt_class->execute();
$result_class = $stmt_class->get_result();
if ($result_class->num_rows == 0) {
    $_SESSION['message'] = "Lớp học không tồn tại.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}
$class = $result_class->fetch_assoc();
$stmt_class->close();

if ($class['teacher_id'] == $user_id) {
    $is_teacher_of_class = true;
}

$stmt_enroll_check = $conn->prepare("SELECT id FROM enrollments WHERE user_id = ? AND class_id = ?");
$stmt_enroll_check->bind_param("ii", $user_id, $class_id);
$stmt_enroll_check->execute();
$stmt_enroll_check->store_result();
if ($stmt_enroll_check->num_rows > 0) {
    $is_enrolled = true;
}
$stmt_enroll_check->close();

if (!$is_teacher_of_class && !$is_enrolled) {
    $_SESSION['message'] = "Bạn không có quyền truy cập lớp học này.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}

// Determine active tab
$active_tab = $_GET['tab'] ?? 'info'; // Default tab

// Fetch members
$members = [];
$stmt_members = $conn->prepare("SELECT u.id, u.full_name, u.email, u.profile_picture, u.role FROM users u JOIN enrollments e ON u.id = e.user_id WHERE e.class_id = ? ORDER BY u.role DESC, u.full_name ASC");
$stmt_members->bind_param("i", $class_id);
$stmt_members->execute();
$result_members = $stmt_members->get_result();
$student_count_for_progress = 0;
while ($row = $result_members->fetch_assoc()) {
    $members[] = $row;
    if ($row['role'] == 'student') {
        $student_count_for_progress++;
    }
}
$stmt_members->close();

// Fetch assignments
$assignments = [];
$stmt_assignments = $conn->prepare("
    SELECT a.*, 
    (SELECT COUNT(*) FROM submissions s WHERE s.assignment_id = a.id) as total_submissions,
    (SELECT s.id FROM submissions s WHERE s.assignment_id = a.id AND s.student_id = ?) as student_submission_id,
    (SELECT s.status FROM submissions s WHERE s.assignment_id = a.id AND s.student_id = ?) as student_submission_status
    FROM assignments a 
    WHERE a.class_id = ? 
    ORDER BY a.due_date DESC
");
$stmt_assignments->bind_param("iii", $user_id, $user_id, $class_id); // $user_id for student specific submission info
$stmt_assignments->execute();
$result_assignments = $stmt_assignments->get_result();
while ($row = $result_assignments->fetch_assoc()) {
    $assignments[] = $row;
}
$stmt_assignments->close();

?>
<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
    <div>
        <h2 class="mb-1"><?php echo htmlspecialchars($class['class_name']); ?></h2>
        <p class="text-muted mb-0">Giáo viên: <?php echo htmlspecialchars($class['teacher_name']); ?> | Mã lớp: <strong class="text-info"><?php echo htmlspecialchars($class['class_code']); ?></strong></p>
    </div>
    <?php if ($is_teacher_of_class): ?>
        <a href="create_assignment.php?class_id=<?php echo $class_id; ?>" class="btn btn-success mt-2 mt-md-0"><i class="bi bi-plus-lg"></i> Tạo bài tập mới</a>
    <?php endif; ?>
</div>

<ul class="nav nav-tabs mb-3">
    <li class="nav-item">
        <a class="nav-link <?php echo ($active_tab == 'info') ? 'active' : ''; ?>" href="class_view.php?id=<?php echo $class_id; ?>&tab=info"><i class="bi bi-info-circle-fill me-1"></i>Thông tin chung</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo ($active_tab == 'assignments') ? 'active' : ''; ?>" href="class_view.php?id=<?php echo $class_id; ?>&tab=assignments"><i class="bi bi-journal-bookmark-fill me-1"></i>Bài tập <span class="badge bg-secondary"><?php echo count($assignments);?></span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo ($active_tab == 'members') ? 'active' : ''; ?>" href="class_view.php?id=<?php echo $class_id; ?>&tab=members"><i class="bi bi-people-fill me-1"></i>Thành viên <span class="badge bg-secondary"><?php echo count($members);?></span></a>
    </li>
    <?php if ($is_teacher_of_class): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo ($active_tab == 'progress') ? 'active' : ''; ?>" href="class_view.php?id=<?php echo $class_id; ?>&tab=progress"><i class="bi bi-graph-up me-1"></i>Tiến độ</a>
    </li>
    <?php endif; ?>
</ul>

<div class="tab-content card shadow-sm">
    <div class="card-body">
        <!-- Thông tin chung Tab -->
        <div class="tab-pane fade <?php echo ($active_tab == 'info') ? 'show active' : ''; ?>" id="info">
            <h4>Mô tả lớp học</h4>
            <p><?php echo nl2br(htmlspecialchars($class['description'] ?: 'Không có mô tả cho lớp học này.')); ?></p>
            <hr>
            <h4>Thông báo mới nhất (Ví dụ)</h4>
            <div class="alert alert-info">Chào mừng các bạn đến với lớp học! Hãy thường xuyên kiểm tra tab Bài tập để không bỏ lỡ các nhiệm vụ.</div>
            <!-- More general info can be added here -->
        </div>

        <!-- Bài tập Tab -->
        <div class="tab-pane fade <?php echo ($active_tab == 'assignments') ? 'show active' : ''; ?>" id="assignments">
            <h4>Danh sách bài tập</h4>
            <?php if (empty($assignments)): ?>
                <p class="text-muted">Chưa có bài tập nào được giao trong lớp này.</p>
            <?php else: ?>
                <div class="list-group">
                    <?php foreach ($assignments as $assignment):
                        $is_past_due = strtotime($assignment['due_date']) < time();
                        $due_date_formatted = date("d/m/Y H:i", strtotime($assignment['due_date']));
                    ?>
                    <div class="list-group-item mb-2 shadow-sm rounded" id="assignment-<?php echo $assignment['id']; ?>">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1"><?php echo htmlspecialchars($assignment['title']); ?></h5>
                            <small class="<?php echo $is_past_due && !$assignment['student_submission_id'] && !$is_teacher_of_class ? 'text-danger fw-bold' : 'text-muted'; ?>">
                                Hạn nộp: <?php echo $due_date_formatted; ?>
                                <?php if ($is_past_due && !$assignment['student_submission_id'] && !$is_teacher_of_class) echo " (Quá hạn)"; ?>
                            </small>
                        </div>
                        <p class="mb-1 text-muted fst-italic"><?php echo nl2br(htmlspecialchars($assignment['description'] ?: 'Không có mô tả.')); ?></p>
                        <?php if ($assignment['file_path']): ?>
                            <p class="mb-1"><small>Tài liệu đính kèm: <a href="uploads/assignment_files/<?php echo htmlspecialchars($assignment['file_path']); ?>" target="_blank" download><i class="bi bi-paperclip"></i> <?php echo htmlspecialchars($assignment['file_path']); ?></a></small></p>
                        <?php endif; ?>

                        <div class="mt-2">
                        <?php if ($is_teacher_of_class): ?>
                            <small class="text-muted me-3">Đã nộp: <?php echo $assignment['total_submissions']; ?> / <?php echo $student_count_for_progress > 0 ? $student_count_for_progress : '0'; ?> học sinh</small>
                            <a href="view_submissions.php?assignment_id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-info"><i class="bi bi-eye-fill me-1"></i>Xem bài nộp</a>
                            <!-- Add edit/delete assignment buttons here, e.g.
                            <a href="edit_assignment.php?id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-outline-warning ms-1"><i class="bi bi-pencil-fill"></i> Sửa</a>
                            <a href="delete_assignment.php?id=<?php echo $assignment['id']; ?>&class_id=<?php echo $class_id; ?>" class="btn btn-sm btn-outline-danger ms-1 btn-delete-confirm"><i class="bi bi-trash-fill"></i> Xóa</a>
                            -->
                        <?php else: // Student view ?>
                            <?php if ($assignment['student_submission_id']): ?>
                                 <span class="badge bg-success me-2"><i class="bi bi-check-circle-fill me-1"></i>Đã nộp <?php echo ($assignment['student_submission_status'] ? '(' . htmlspecialchars(ucfirst($assignment['student_submission_status'])) . ')' : ''); ?></span>
                                 <a href="submit_assignment.php?assignment_id=<?php echo $assignment['id']; ?>&view=1" class="btn btn-sm btn-outline-secondary"><i class="bi bi-file-earmark-check-fill me-1"></i>Xem bài của tôi</a>
                            <?php elseif ($is_past_due): ?>
                                <span class="badge bg-danger me-2"><i class="bi bi-x-octagon-fill me-1"></i>Quá hạn nộp</span>
                                <!-- Optionally allow late submission with a different button/text -->
                                <a href="submit_assignment.php?assignment_id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-warning disabled"><i class="bi bi-upload me-1"></i>Nộp bài (Đã quá hạn)</a>
                            <?php else: ?>
                                <a href="submit_assignment.php?assignment_id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-primary"><i class="bi bi-upload me-1"></i>Nộp bài</a>
                            <?php endif; ?>
                        <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Thành viên Tab -->
        <div class="tab-pane fade <?php echo ($active_tab == 'members') ? 'show active' : ''; ?>" id="members">
            <h4>Danh sách thành viên (<?php echo count($members); ?>)</h4>
            <ul class="list-group">
                <?php foreach ($members as $member): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <img src="uploads/profile_pictures/<?php echo htmlspecialchars($member['profile_picture'] ?: 'default.png'); ?>"
                             alt="<?php echo htmlspecialchars($member['full_name']); ?>" class="profile-picture-sm me-2"
                             onerror="this.onerror=null;this.src='uploads/profile_pictures/default.png';">
                        <?php echo htmlspecialchars($member['full_name']); ?>
                        <small class="text-muted ms-1">(<?php echo htmlspecialchars($member['email']); ?>)</small>
                    </div>
                    <span class="badge bg-<?php echo ($member['role'] == 'teacher') ? 'primary' : 'secondary'; ?> rounded-pill">
                        <?php echo ucfirst(htmlspecialchars($member['role'] == 'teacher' ? 'Giáo viên' : 'Học sinh')); ?>
                    </span>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Tiến độ Tab (Teacher only) -->
        <?php if ($is_teacher_of_class): ?>
        <div class="tab-pane fade <?php echo ($active_tab == 'progress') ? 'show active' : ''; ?>" id="progress">
            <h4>Theo dõi tiến độ học tập</h4>
            <?php if (empty($assignments)): ?>
                <p class="text-muted">Chưa có bài tập nào trong lớp để theo dõi tiến độ.</p>
            <?php elseif ($student_count_for_progress == 0): ?>
                 <p class="text-muted">Chưa có học sinh nào trong lớp để theo dõi tiến độ.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Bài tập</th>
                                <th class="text-center">Số lượng đã nộp</th>
                                <th class="text-center" style="min-width: 150px;">Tỷ lệ hoàn thành</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        foreach ($assignments as $assignment):
                            $completion_rate = ($student_count_for_progress > 0) ? ($assignment['total_submissions'] / $student_count_for_progress) * 100 : 0;
                        ?>
                            <tr>
                                <td><a href="view_submissions.php?assignment_id=<?php echo $assignment['id']; ?>" class="text-decoration-none"><?php echo htmlspecialchars($assignment['title']); ?></a></td>
                                <td class="text-center"><?php echo $assignment['total_submissions']; ?> / <?php echo $student_count_for_progress; ?></td>
                                <td>
                                    <div class="progress" style="height: 20px;">
                                        <div class="progress-bar <?php 
                                            if ($completion_rate < 30) echo 'bg-danger'; 
                                            elseif ($completion_rate < 70) echo 'bg-warning'; 
                                            else echo 'bg-success'; 
                                        ?>" role="progressbar" style="width: <?php echo $completion_rate; ?>%;" aria-valuenow="<?php echo $completion_rate; ?>" aria-valuemin="0" aria-valuemax="100"><?php echo round($completion_rate,1); ?>%</div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>


<?php require_once 'includes/footer.php'; ?>