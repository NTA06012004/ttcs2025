<?php
// require_once 'db.php'; // db.php will be included by files needing functions

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() { // Or isTeacher()
    return isset($_SESSION['role']) && $_SESSION['role'] == 'teacher';
}

function isStudent() {
    return isset($_SESSION['role']) && $_SESSION['role'] == 'student';
}

function redirect($url) {
    header("Location: " . $url);
    exit();
}

function generateVerificationCode($length = 6) {
    return substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
}

function sendVerificationEmail($email, $code) {
    $subject = "Verify Your Email Address";
    $message = "Your verification code is: " . $code . "\n";
    $message .= "This code will expire in 10 minutes.\n";
    $headers = "From: no-reply@yourwebsite.com"; // Change this

    // For actual sending, you'd use mail() or a library like PHPMailer
    // mail($email, $subject, $message, $headers);
    // For now, we can simulate or log it:
    error_log("Verification email to $email: Code $code");
    return true; // Simulate success
}

function get_user_by_id($conn, $user_id) {
    $stmt = $conn->prepare("SELECT id, full_name, email, role, dob, gender, profile_picture FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
?>