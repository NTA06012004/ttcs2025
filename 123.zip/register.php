<?php
require_once 'includes/header.php';
if (isLoggedIn()) { redirect('dashboard.php'); }

$full_name = $dob = $gender = $email = $role = '';
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once 'includes/db.php'; // Ensure $conn is available

    $full_name = trim($_POST['full_name']);
    $dob = trim($_POST['dob']);
    $gender = $_POST['gender'] ?? '';
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'] ?? '';

    // Basic Validation
    if (empty($full_name)) $errors['full_name'] = "Họ tên là bắt buộc.";
    if (empty($dob)) $errors['dob'] = "Ngày sinh là bắt buộc.";
    if (empty($gender)) $errors['gender'] = "Giới tính là bắt buộc.";
    if (empty($email)) {
        $errors['email'] = "Email là bắt buộc.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Định dạng email không hợp lệ.";
    } else {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $errors['email'] = "Email đã được sử dụng.";
        }
        $stmt->close();
    }
    if (empty($password)) {
        $errors['password'] = "Mật khẩu là bắt buộc.";
    } elseif (strlen($password) < 6) {
        $errors['password'] = "Mật khẩu phải có ít nhất 6 ký tự.";
    }
    if ($password !== $confirm_password) {
        $errors['confirm_password'] = "Mật khẩu xác nhận không khớp.";
    }
    if (empty($role)) $errors['role'] = "Vai trò là bắt buộc.";


    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $verification_code = generateVerificationCode();
        // Store code with expiry (e.g., store NOW() + 10 minutes in DB, or just the code)
        // For simplicity, we'll just store the code and assume it's handled on verification page.

        $stmt = $conn->prepare("INSERT INTO users (full_name, dob, gender, email, password, role, email_verification_code) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $full_name, $dob, $gender, $email, $hashed_password, $role, $verification_code);

        if ($stmt->execute()) {
            if (sendVerificationEmail($email, $verification_code)) {
                $_SESSION['message'] = "Đăng ký thành công! Vui lòng kiểm tra email (" . htmlspecialchars($email) . ") để xác thực tài khoản. Mã xác thực của bạn là: " . $verification_code . " (Đây là mô phỏng, email thực tế chưa được gửi).";
                $_SESSION['message_type'] = "success";
                 // In a real app, redirect to a page like: verify_notice.php?email=$email
                redirect("verify_email.php?email=" . urlencode($email));
            } else {
                // This case is less likely with current sendVerificationEmail which always returns true
                $_SESSION['message'] = "Đăng ký thành công nhưng không thể gửi email xác thực. Vui lòng liên hệ quản trị viên.";
                $_SESSION['message_type'] = "warning";
                // Fallback: log the code or show it if email fails critically
                error_log("CRITICAL: Failed to send verification email for $email. Code: $verification_code");
                redirect("login.php"); 
            }
        } else {
            $errors['db_error'] = "Lỗi đăng ký: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h3 class="text-center mb-0">Đăng ký tài khoản</h3>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($errors['db_error'])): ?>
                    <div class="alert alert-danger"><?php echo $errors['db_error']; ?></div>
                <?php endif; ?>
                <form action="register.php" method="POST">
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Họ và tên <span class="text-danger">*</span></label>
                        <input type="text" class="form-control <?php echo isset($errors['full_name']) ? 'is-invalid' : ''; ?>" id="full_name" name="full_name" value="<?php echo htmlspecialchars($full_name); ?>" required>
                        <?php if (isset($errors['full_name'])): ?><div class="invalid-feedback"><?php echo $errors['full_name']; ?></div><?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="dob" class="form-label">Ngày sinh <span class="text-danger">*</span></label>
                        <input type="date" class="form-control <?php echo isset($errors['dob']) ? 'is-invalid' : ''; ?>" id="dob" name="dob" value="<?php echo htmlspecialchars($dob); ?>" required>
                        <?php if (isset($errors['dob'])): ?><div class="invalid-feedback"><?php echo $errors['dob']; ?></div><?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Giới tính <span class="text-danger">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input <?php echo isset($errors['gender']) ? 'is-invalid' : ''; ?>" type="radio" name="gender" id="male" value="male" <?php echo ($gender == 'male') ? 'checked' : ''; ?> required>
                                <label class="form-check-label" for="male">Nam</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input <?php echo isset($errors['gender']) ? 'is-invalid' : ''; ?>" type="radio" name="gender" id="female" value="female" <?php echo ($gender == 'female') ? 'checked' : ''; ?> required>
                                <label class="form-check-label" for="female">Nữ</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input <?php echo isset($errors['gender']) ? 'is-invalid' : ''; ?>" type="radio" name="gender" id="other" value="other" <?php echo ($gender == 'other') ? 'checked' : ''; ?> required>
                                <label class="form-check-label" for="other">Khác</label>
                            </div>
                        </div>
                        <?php if (isset($errors['gender'])): ?><div class="invalid-feedback d-block"><?php echo $errors['gender']; ?></div><?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Địa chỉ Email <span class="text-danger">*</span></label>
                        <input type="email" class="form-control <?php echo isset($errors['email']) ? 'is-invalid' : ''; ?>" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                        <?php if (isset($errors['email'])): ?><div class="invalid-feedback"><?php echo $errors['email']; ?></div><?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Mật khẩu <span class="text-danger">*</span></label>
                        <input type="password" class="form-control <?php echo isset($errors['password']) ? 'is-invalid' : ''; ?>" id="password" name="password" required>
                        <?php if (isset($errors['password'])): ?><div class="invalid-feedback"><?php echo $errors['password']; ?></div><?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Xác nhận mật khẩu <span class="text-danger">*</span></label>
                        <input type="password" class="form-control <?php echo isset($errors['confirm_password']) ? 'is-invalid' : ''; ?>" id="confirm_password" name="confirm_password" required>
                        <?php if (isset($errors['confirm_password'])): ?><div class="invalid-feedback"><?php echo $errors['confirm_password']; ?></div><?php endif; ?>
                    </div>
                     <div class="mb-3">
                        <label class="form-label">Bạn là? <span class="text-danger">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input <?php echo isset($errors['role']) ? 'is-invalid' : ''; ?>" type="radio" name="role" id="student" value="student" <?php echo ($role == 'student') ? 'checked' : ''; ?> required>
                                <label class="form-check-label" for="student">Học sinh</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input <?php echo isset($errors['role']) ? 'is-invalid' : ''; ?>" type="radio" name="role" id="teacher" value="teacher" <?php echo ($role == 'teacher') ? 'checked' : ''; ?> required>
                                <label class="form-check-label" for="teacher">Giáo viên</label>
                            </div>
                        </div>
                         <?php if (isset($errors['role'])): ?><div class="invalid-feedback d-block"><?php echo $errors['role']; ?></div><?php endif; ?>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">Đăng ký</button>
                    </div>
                </form>
                <p class="text-center mt-3">
                    Đã có tài khoản? <a href="login.php">Đăng nhập tại đây</a>
                </p>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>