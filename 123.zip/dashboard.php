<?php
require_once 'includes/header.php';
if (!isLoggedIn()) { redirect('login.php'); }

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$user_info = get_user_by_id($conn, $user_id); // Fetch user details

// Fetch classes user is managing (teacher) or enrolled in (student)
$classes = [];
if ($user_role == 'teacher') {
    $stmt = $conn->prepare("SELECT id, class_name, class_code, description FROM classes WHERE teacher_id = ? ORDER BY created_at DESC");
    $stmt->bind_param("i", $user_id);
} else { // student
    $stmt = $conn->prepare("
        SELECT c.id, c.class_name, c.class_code, c.description
        FROM classes c
        JOIN enrollments e ON c.id = e.class_id
        WHERE e.user_id = ?
        ORDER BY c.class_name ASC
    ");
    $stmt->bind_param("i", $user_id);
}
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    // Get member count for each class
    $count_stmt = $conn->prepare("SELECT COUNT(DISTINCT user_id) as member_count FROM enrollments WHERE class_id = ?"); // COUNT(DISTINCT user_id) to be sure
    $count_stmt->bind_param("i", $row['id']);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $member_count_row = $count_result->fetch_assoc();
    $row['member_count'] = $member_count_row['member_count'];
    $classes[] = $row;
    $count_stmt->close();
}
$stmt->close();

// Fetch upcoming assignments (simplified for dashboard)
$upcoming_assignments = [];
$assignment_query_sql_student = "
    SELECT a.title, a.due_date, c.class_name, a.id as assignment_id, c.id as class_id
    FROM assignments a
    JOIN classes c ON a.class_id = c.id
    JOIN enrollments e ON c.id = e.class_id
    WHERE e.user_id = ? AND a.due_date >= CURDATE() AND 
          NOT EXISTS (SELECT 1 FROM submissions s WHERE s.assignment_id = a.id AND s.student_id = ?)
    ORDER BY a.due_date ASC
    LIMIT 5
";
$assignment_query_sql_teacher = "
    SELECT a.title, a.due_date, c.class_name, a.id as assignment_id, c.id as class_id
    FROM assignments a
    JOIN classes c ON a.class_id = c.id
    WHERE c.teacher_id = ? AND a.due_date >= CURDATE()
    ORDER BY a.due_date ASC
    LIMIT 5
";

if ($user_role == 'teacher') {
    $stmt_assign = $conn->prepare($assignment_query_sql_teacher);
    $stmt_assign->bind_param("i", $user_id);
} else {
    $stmt_assign = $conn->prepare($assignment_query_sql_student);
    $stmt_assign->bind_param("ii", $user_id, $user_id);
}

$stmt_assign->execute();
$assign_result = $stmt_assign->get_result();
while ($assign_row = $assign_result->fetch_assoc()) {
    $upcoming_assignments[] = $assign_row;
}
$stmt_assign->close();

?>

<div class="row">
    <div class="col-md-4 col-lg-3">
        <div class="card shadow-sm mb-4">
            <div class="card-body text-center">
                <img src="uploads/profile_pictures/<?php echo htmlspecialchars($user_info['profile_picture'] ?: 'default.png'); ?>"
                     alt="Ảnh đại diện" class="profile-picture-lg img-thumbnail mb-2"
                     onerror="this.onerror=null;this.src='uploads/profile_pictures/default.png';">
                <h4><?php echo htmlspecialchars($_SESSION['full_name']); ?></h4>
                <p class="text-muted mb-2"><?php echo ucfirst(htmlspecialchars($user_role == 'teacher' ? 'Giáo viên' : 'Học sinh')); ?></p>
                <a href="settings.php" class="btn btn-outline-secondary btn-sm w-100">Cài đặt tài khoản</a>
            </div>
        </div>
        <div class="list-group shadow-sm">
             <a href="dashboard.php" class="list-group-item list-group-item-action <?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'active' : '';?>"><i class="bi bi-house-door-fill me-2"></i>Bảng điều khiển</a>
             <a href="calendar.php" class="list-group-item list-group-item-action <?php echo (basename($_SERVER['PHP_SELF']) == 'calendar.php') ? 'active' : '';?>"><i class="bi bi-calendar-event-fill me-2"></i>Lịch</a>
             <a href="todo.php" class="list-group-item list-group-item-action <?php echo (basename($_SERVER['PHP_SELF']) == 'todo.php') ? 'active' : '';?>"><i class="bi bi-check2-square me-2"></i>Việc cần làm</a>
             <?php if ($user_role == 'teacher'): ?>
                <a href="create_class.php" class="list-group-item list-group-item-action"><i class="bi bi-plus-circle-fill me-2"></i>Tạo lớp học mới</a>
             <?php else: ?>
                <a href="join_class.php" class="list-group-item list-group-item-action"><i class="bi bi-person-plus-fill me-2"></i>Tham gia lớp học</a>
             <?php endif; ?>
        </div>
    </div>

    <div class="col-md-8 col-lg-9">
        <h2>Bảng điều khiển của bạn</h2>
        <hr>

        <h4><i class="bi bi-collection-fill text-primary me-2"></i>Các lớp học của tôi</h4>
        <?php if (empty($classes)): ?>
            <div class="alert alert-info">
                <?php if ($user_role == 'teacher'): ?>
                    Bạn chưa quản lý lớp học nào. <a href="create_class.php" class="alert-link">Tạo lớp học mới</a>.
                <?php else: ?>
                    Bạn chưa tham gia lớp học nào. <a href="join_class.php" class="alert-link">Tham gia bằng mã lớp</a>.
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php foreach ($classes as $class): ?>
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?php echo htmlspecialchars($class['class_name']); ?></h5>
                            <p class="card-text flex-grow-1">
                                <small class="text-muted d-block">Mã lớp: <?php echo htmlspecialchars($class['class_code']); ?></small>
                                <small class="text-muted d-block">Số thành viên: <?php echo $class['member_count']; ?></small>
                                <?php if (!empty($class['description'])): ?>
                                     <small class="text-muted d-block mt-1 fst-italic">Mô tả: <?php echo htmlspecialchars(mb_substr($class['description'], 0, 50)); ?>...</small>
                                <?php endif; ?>
                            </p>
                            <a href="class_view.php?id=<?php echo $class['id']; ?>" class="btn btn-primary mt-auto">Xem lớp học</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <h4 class="mt-5"><i class="bi bi-bell-fill text-warning me-2"></i>Thông báo & Bài tập sắp đến hạn</h4>
        <?php if (empty($upcoming_assignments)): ?>
            <div class="alert alert-light text-muted">Không có bài tập nào sắp đến hạn<?php echo ($user_role == 'student') ? ' hoặc bạn đã hoàn thành tất cả' : ''; ?>.</div>
        <?php else: ?>
            <ul class="list-group shadow-sm">
                <?php foreach ($upcoming_assignments as $assignment): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <strong><a href="class_view.php?id=<?php echo $assignment['class_id']; ?>&tab=assignments" class="text-decoration-none"><?php echo htmlspecialchars($assignment['title']); ?></a></strong> (<?php echo htmlspecialchars($assignment['class_name']); ?>)<br>
                        <small class="text-danger">Hạn nộp: <?php echo date("d/m/Y H:i", strtotime($assignment['due_date'])); ?></small>
                    </div>
                    <a href="class_view.php?id=<?php echo $assignment['class_id']; ?>&tab=assignments" class="btn btn-sm btn-outline-info">Chi tiết</a>
                </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>