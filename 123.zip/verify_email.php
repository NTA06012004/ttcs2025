<?php
require_once 'includes/header.php'; // db.php is included in header.php
$errors = [];
$email_to_verify = $_GET['email'] ?? '';

if (empty($email_to_verify)) {
    $_SESSION['message'] = "Không có email nào được cung cấp để xác thực.";
    $_SESSION['message_type'] = "warning";
    redirect("register.php");
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code = trim($_POST['verification_code']);
    $email = trim($_POST['email']); // Get email from hidden input

    if (empty($code)) {
        $errors['code'] = "Mã xác thực là bắt buộc.";
    }
    if (empty($email)) { // Should not happen if form is correct
        $errors['general'] = "Không tìm thấy email để xác thực.";
        $email_to_verify = ''; // Reset if POST email is missing
    } else {
        $email_to_verify = $email; // Ensure $email_to_verify is set for display even on POST error
    }


    if (empty($errors)) {
        // Check code and expiry (add expiry logic if you store it in DB)
        $stmt = $conn->prepare("SELECT id, email_verification_code FROM users WHERE email = ? AND email_verified_at IS NULL");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        if ($user && $user['email_verification_code'] === $code) {
            // Optional: Check code expiry here if you implemented it
            // e.g. if (strtotime($user['verification_code_expires_at']) < time()) { $errors['code'] = "Mã đã hết hạn."; }
            $stmt_update = $conn->prepare("UPDATE users SET email_verified_at = NOW(), email_verification_code = NULL WHERE email = ?");
            $stmt_update->bind_param("s", $email);
            if ($stmt_update->execute()) {
                $_SESSION['message'] = "Xác thực email thành công! Bạn có thể đăng nhập.";
                $_SESSION['message_type'] = "success";
                redirect("login.php");
            } else {
                $errors['general'] = "Lỗi cập nhật trạng thái xác thực.";
            }
            $stmt_update->close();
        } else {
            $errors['code'] = "Mã xác thực không hợp lệ hoặc đã hết hạn/đã được sử dụng.";
        }
    }
}

// Option to resend code (simplified, no rate limiting)
if (isset($_GET['resend']) && !empty($_GET['email_resend'])) { // use a different param name to avoid conflict
    $email_to_resend = $_GET['email_resend'];
    $stmt = $conn->prepare("SELECT id, email_verification_code, email_verified_at FROM users WHERE email = ?");
    $stmt->bind_param("s", $email_to_resend);
    $stmt->execute();
    $result = $stmt->get_result();
    $user_for_resend = $result->fetch_assoc();

    if ($user_for_resend) {
        if ($user_for_resend['email_verified_at'] !== NULL) {
            $_SESSION['message'] = "Email " . htmlspecialchars($email_to_resend) . " đã được xác thực.";
            $_SESSION['message_type'] = "info";
        } else {
            $new_code = generateVerificationCode();
            // You might want to update an expiry time here too if implemented
            $stmt_update_code = $conn->prepare("UPDATE users SET email_verification_code = ? WHERE email = ?");
            $stmt_update_code->bind_param("ss", $new_code, $email_to_resend);
            if ($stmt_update_code->execute() && sendVerificationEmail($email_to_resend, $new_code)) {
                 $_SESSION['message'] = "Mã xác thực mới đã được gửi tới " . htmlspecialchars($email_to_resend) . ". Mã mới: " . $new_code . " (Mô phỏng).";
                 $_SESSION['message_type'] = "info";
            } else {
                 $_SESSION['message'] = "Không thể gửi lại mã xác thực. Vui lòng thử lại sau.";
                 $_SESSION['message_type'] = "danger";
            }
            $stmt_update_code->close();
        }
    } else {
        $_SESSION['message'] = "Email không tồn tại trong hệ thống.";
        $_SESSION['message_type'] = "warning";
    }
    redirect("verify_email.php?email=" . urlencode($email_to_resend)); // Redirect back to the verification page for this email
}


?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h3 class="text-center mb-0">Xác thực Email</h3>
            </div>
            <div class="card-body p-4">
                <p class="text-center">Một mã xác thực đã được gửi đến email <br><strong><?php echo htmlspecialchars($email_to_verify); ?></strong>. <br>Vui lòng nhập mã đó vào ô bên dưới.</p>
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <p class="mb-0"><?php echo $error; ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form action="verify_email.php?email=<?php echo urlencode($email_to_verify); ?>" method="POST">
                    <input type="hidden" name="email" value="<?php echo htmlspecialchars($email_to_verify); ?>">
                    <div class="mb-3">
                        <label for="verification_code" class="form-label">Mã xác thực</label>
                        <input type="text" class="form-control <?php echo isset($errors['code']) ? 'is-invalid' : ''; ?>" id="verification_code" name="verification_code" required autofocus>
                         <?php if (isset($errors['code'])): ?><div class="invalid-feedback"><?php echo $errors['code']; ?></div><?php endif; ?>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">Xác thực</button>
                    </div>
                </form>
                <p class="text-center mt-3">
                    Không nhận được mã? <a href="verify_email.php?resend=true&email_resend=<?php echo urlencode($email_to_verify); ?>">Gửi lại mã</a>
                </p>
                 <p class="text-center mt-2">
                    <a href="register.php">Đăng ký tài khoản khác</a> | <a href="login.php">Đăng nhập</a>
                </p>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>