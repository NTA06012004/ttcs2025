<?php
require_once 'includes/header.php';
if (!isLoggedIn()) { redirect('login.php'); }

$user_id = $_SESSION['user_id'];
$user = get_user_by_id($conn, $user_id); // Fetch current user details

$errors = [];
$success_msg = '';

// Handle Profile Info Update (Allowing Full Name, DOB, Gender to be editable as per spec)
if (isset($_POST['update_info'])) {
    $full_name = trim($_POST['full_name']);
    $dob = trim($_POST['dob']); 
    $gender = $_POST['gender'] ?? '';

    if (empty($full_name)) {
        $errors['info'] = "Họ tên không được để trống.";
    }
    if (empty($dob)) { // Add validation for DOB format if needed
        $errors['info'] = "Ngày sinh không được để trống.";
    }
     if (empty($gender)) {
        $errors['info'] = "Giới tính không được để trống.";
    }
    // Add more validation for other fields if they are editable

    if (empty($errors['info'])) {
        $stmt = $conn->prepare("UPDATE users SET full_name = ?, dob = ?, gender = ? WHERE id = ?");
        $stmt->bind_param("sssi", $full_name, $dob, $gender, $user_id);

        if ($stmt->execute()) {
            $_SESSION['full_name'] = $full_name; // Update session name
            $success_msg = "Thông tin cá nhân đã được cập nhật.";
            $_SESSION['message'] = $success_msg; // Use session message for redirect consistency
            $_SESSION['message_type'] = "success";
            redirect('settings.php'); // Redirect to show updated info and clear POST
            exit;
        } else {
            $errors['info'] = "Lỗi cập nhật thông tin: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle Password Change
if (isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_new_password = $_POST['confirm_new_password'];

    if (empty($current_password) || empty($new_password) || empty($confirm_new_password)) {
        $errors['password'] = "Tất cả các trường mật khẩu là bắt buộc.";
    } elseif ($new_password !== $confirm_new_password) {
        $errors['password'] = "Mật khẩu mới không khớp.";
    } elseif (strlen($new_password) < 6) {
        $errors['password'] = "Mật khẩu mới phải có ít nhất 6 ký tự.";
    } else {
        // Verify current password
        $stmt_check = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt_check->bind_param("i", $user_id);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        $user_data_for_pass = $result_check->fetch_assoc(); // Renamed to avoid conflict
        $stmt_check->close();

        if ($user_data_for_pass && password_verify($current_password, $user_data_for_pass['password'])) {
            $hashed_new_password = password_hash($new_password, PASSWORD_BCRYPT);
            $stmt_update = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt_update->bind_param("si", $hashed_new_password, $user_id);
            if ($stmt_update->execute()) {
                $success_msg = "Mật khẩu đã được thay đổi thành công.";
                $_SESSION['message'] = $success_msg;
                $_SESSION['message_type'] = "success";
                 // Log out user after password change for security? Optional.
                // redirect('logout.php?password_changed=1');
                redirect('settings.php');
                exit;
            } else {
                $errors['password'] = "Lỗi thay đổi mật khẩu: " . $stmt_update->error;
            }
            $stmt_update->close();
        } else {
            $errors['password'] = "Mật khẩu hiện tại không chính xác.";
        }
    }
}

// Handle Profile Picture Upload
if (isset($_POST['upload_picture']) && isset($_FILES['profile_picture_file'])) {
    if ($_FILES['profile_picture_file']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/profile_pictures/';
        if (!is_dir($upload_dir)) {
            if(!mkdir($upload_dir, 0777, true) && !is_dir($upload_dir)) {
                $errors['picture'] = "Không thể tạo thư mục tải lên: " . $upload_dir;
            }
        }
        
        if(empty($errors['picture'])) {
            $file_tmp_name = $_FILES['profile_picture_file']['tmp_name'];
            // Sanitize filename
            $original_file_name = basename($_FILES['profile_picture_file']['name']);
            $safe_file_name = preg_replace("/[^a-zA-Z0-9.\-_]/", "_", $original_file_name);
            $file_name = $user_id . '_' . time() . '_' . $safe_file_name;
            
            $target_file = $upload_dir . $file_name;
            $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

            if ($_FILES['profile_picture_file']['size'] > 2000000) { // 2MB
                $errors['picture'] = "Ảnh đại diện quá lớn (tối đa 2MB).";
            } elseif (!in_array($file_type, $allowed_types)) {
                $errors['picture'] = "Chỉ cho phép ảnh JPG, JPEG, PNG, GIF.";
            } else {
                // Delete old picture if not default and exists
                if ($user['profile_picture'] && $user['profile_picture'] != 'default.png' && file_exists($upload_dir . $user['profile_picture'])) {
                    unlink($upload_dir . $user['profile_picture']);
                }
                if (move_uploaded_file($file_tmp_name, $target_file)) {
                    $stmt_pic = $conn->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
                    $stmt_pic->bind_param("si", $file_name, $user_id);
                    if ($stmt_pic->execute()) {
                        $success_msg = "Ảnh đại diện đã được cập nhật.";
                        $_SESSION['message'] = $success_msg;
                        $_SESSION['message_type'] = "success";
                        redirect('settings.php');
                        exit;
                    } else {
                        $errors['picture'] = "Lỗi cập nhật ảnh trong CSDL.";
                    }
                    $stmt_pic->close();
                } else {
                    $errors['picture'] = "Lỗi khi tải ảnh lên. Kiểm tra quyền ghi của thư mục. Error code: " . $_FILES['profile_picture_file']['error'];
                }
            }
        }
    } elseif ($_FILES['profile_picture_file']['error'] != UPLOAD_ERR_NO_FILE) {
        $errors['picture'] = "Lỗi tệp: " . error_upload_message($_FILES['profile_picture_file']['error']);
    }
}

// Helper for upload errors
function error_upload_message($code) {
    switch ($code) {
        case UPLOAD_ERR_INI_SIZE: return "Tệp quá lớn (theo cấu hình máy chủ).";
        case UPLOAD_ERR_FORM_SIZE: return "Tệp quá lớn (theo cấu hình form).";
        case UPLOAD_ERR_PARTIAL: return "Tệp chỉ được tải lên một phần.";
        case UPLOAD_ERR_NO_FILE: return "Không có tệp nào được tải lên."; // Should be handled before calling this
        case UPLOAD_ERR_NO_TMP_DIR: return "Thiếu thư mục tạm.";
        case UPLOAD_ERR_CANT_WRITE: return "Không thể ghi tệp vào đĩa.";
        case UPLOAD_ERR_EXTENSION: return "Một tiện ích PHP đã chặn việc tải tệp lên.";
        default: return "Lỗi tải tệp không xác định.";
    }
}

// Refresh user data if not redirected (e.g. on initial load or after non-redirecting error)
if (empty($success_msg) && empty($errors) && $_SERVER['REQUEST_METHOD'] != 'POST') {
    $user = get_user_by_id($conn, $user_id);
}


?>
<h2><i class="bi bi-gear-fill me-2"></i>Cài đặt tài khoản</h2>
<hr>

<?php if ($success_msg && empty($_SESSION['message']) ): // Show only if not set by redirect ?>
    <div class="alert alert-success"><?php echo $success_msg; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card shadow-sm">
            <div class="card-header">
                <h4 class="mb-0">Ảnh đại diện</h4>
            </div>
            <div class="card-body text-center">
                <img src="uploads/profile_pictures/<?php echo htmlspecialchars($user['profile_picture'] ?: 'default.png'); ?>"
                     alt="Ảnh đại diện" class="profile-picture-lg img-thumbnail mb-3"
                     onerror="this.onerror=null;this.src='uploads/profile_pictures/default.png';">

                <?php if (isset($errors['picture'])): ?><div class="alert alert-danger mt-2"><?php echo $errors['picture']; ?></div><?php endif; ?>
                <form action="settings.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="profile_picture_file" class="form-label visually-hidden">Tải lên ảnh mới:</label>
                        <input class="form-control" type="file" id="profile_picture_file" name="profile_picture_file" required>
                    </div>
                    <button type="submit" name="upload_picture" class="btn btn-primary w-100"><i class="bi bi-upload me-1"></i>Tải lên</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h4 class="mb-0">Thông tin cá nhân</h4>
            </div>
            <div class="card-body">
                <?php if (isset($errors['info'])): ?><div class="alert alert-danger"><?php echo $errors['info']; ?></div><?php endif; ?>
                <form action="settings.php" method="POST">
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Họ và tên <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" readonly disabled>
                        <div class="form-text">Email không thể thay đổi.</div>
                    </div>
                    <div class="mb-3">
                        <label for="dob" class="form-label">Ngày sinh <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="dob" name="dob" value="<?php echo htmlspecialchars($user['dob']); ?>" required>
                    </div>
                     <div class="mb-3">
                        <label class="form-label">Giới tính <span class="text-danger">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="male_settings" value="male" <?php echo ($user['gender'] == 'male') ? 'checked' : ''; ?> required>
                                <label class="form-check-label" for="male_settings">Nam</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="female_settings" value="female" <?php echo ($user['gender'] == 'female') ? 'checked' : ''; ?> required>
                                <label class="form-check-label" for="female_settings">Nữ</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="other_settings" value="other" <?php echo ($user['gender'] == 'other') ? 'checked' : ''; ?> required>
                                <label class="form-check-label" for="other_settings">Khác</label>
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="update_info" class="btn btn-primary"><i class="bi bi-save me-1"></i>Cập nhật thông tin</button>
                </form>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-header">
                <h4 class="mb-0">Thay đổi mật khẩu</h4>
            </div>
            <div class="card-body">
                <?php if (isset($errors['password'])): ?><div class="alert alert-danger"><?php echo $errors['password']; ?></div><?php endif; ?>
                <form action="settings.php" method="POST">
                    <div class="mb-3">
                        <label for="current_password" class="form-label">Mật khẩu hiện tại <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                    </div>
                    <div class="mb-3">
                        <label for="new_password" class="form-label">Mật khẩu mới <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_new_password" class="form-label">Xác nhận mật khẩu mới <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" id="confirm_new_password" name="confirm_new_password" required>
                    </div>
                    <button type="submit" name="change_password" class="btn btn-primary"><i class="bi bi-shield-lock-fill me-1"></i>Đổi mật khẩu</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>