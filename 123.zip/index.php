<?php require_once 'includes/header.php'; ?>

<?php if (isLoggedIn()) { redirect('dashboard.php'); } // Redirect if already logged in ?>

<div class="hero-section">
    <div class="container">
        <h1>Chào mừng đến với Nền tảng Giáo dục Trực tuyến</h1>
        <p class="lead">Kết nối giáo viên và học sinh, quản lý lớp học và bài tập một cách hiệu quả.</p>
        <p>
            <a href="login.php" class="btn btn-primary btn-lg me-2">Đăng nhập</a>
            <a href="register.php" class="btn btn-success btn-lg">Đăng ký</a>
        </p>
    </div>
</div>

<div class="container mt-5">
    <div class="row text-center">
        <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
                <div class="card-body">
                    <i class="bi bi-easel2-fill fs-1 text-primary mb-3"></i>
                    <h5 class="card-title">Quản lý Lớp học</h5>
                    <p class="card-text">Tạo và quản lý lớp học, thêm học sinh, giao bài tập dễ dàng.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
                <div class="card-body">
                    <i class="bi bi-file-earmark-text-fill fs-1 text-success mb-3"></i>
                    <h5 class="card-title">Bài tập & Nộp bài</h5>
                    <p class="card-text">Giao bài tập với thời hạn, học sinh nộp bài trực tuyến.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
                <div class="card-body">
                    <i class="bi bi-calendar-check-fill fs-1 text-info mb-3"></i>
                    <h5 class="card-title">Theo dõi Tiến độ</h5>
                    <p class="card-text">Lịch biểu cá nhân, danh sách việc cần làm, thông báo nhắc nhở.</p>
                </div>
            </div>
        </div>
    </div>

    <hr class="my-5">

    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h2 class="text-center mb-4">Tại sao chọn chúng tôi?</h2>
            <p>Hệ thống của chúng tôi được thiết kế để cung cấp một môi trường học tập và giảng dạy trực tuyến toàn diện, giúp người dùng mới nhanh chóng hiểu được giá trị và bắt đầu sử dụng một cách dễ dàng. Với giao diện hiện đại, thẩm mỹ và các tính năng nổi bật, chúng tôi cam kết mang lại trải nghiệm tốt nhất.</p>
            <ul class="list-unstyled">
                <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Giao diện trực quan, dễ sử dụng.</li>
                <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Tính năng quản lý lớp học mạnh mẽ cho giáo viên.</li>
                <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Hệ thống nộp và chấm bài tập tiện lợi.</li>
                <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Thông báo và nhắc nhở tự động.</li>
                <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Bảo mật thông tin người dùng.</li>
            </ul>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>