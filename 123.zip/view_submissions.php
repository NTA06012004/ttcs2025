<?php
require_once 'includes/header.php';
if (!isLoggedIn() || !isAdmin()) {
    $_SESSION['message'] = "Bạn không có quyền truy cập trang này.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}

$assignment_id = isset($_GET['assignment_id']) ? (int)$_GET['assignment_id'] : 0;
if ($assignment_id <= 0) {
    $_SESSION['message'] = "ID bài tập không hợp lệ.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}

// Fetch assignment details and verify teacher owns the class of this assignment
$stmt_assign = $conn->prepare("
    SELECT a.*, c.id as class_id, c.class_name, c.teacher_id
    FROM assignments a
    JOIN classes c ON a.class_id = c.id
    WHERE a.id = ?
");
$stmt_assign->bind_param("i", $assignment_id);
$stmt_assign->execute();
$result_assign = $stmt_assign->get_result();
if ($result_assign->num_rows == 0) {
    $_SESSION['message'] = "Bài tập không tồn tại.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}
$assignment = $result_assign->fetch_assoc();
$stmt_assign->close();

if ($assignment['teacher_id'] != $_SESSION['user_id']) {
    $_SESSION['message'] = "Bạn không phải giáo viên của lớp này để xem bài nộp.";
    $_SESSION['message_type'] = "danger";
    redirect("class_view.php?id={$assignment['class_id']}&tab=assignments");
}

// Handle grading/feedback submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submission_id'])) {
    $submission_id_to_grade = (int)$_POST['submission_id'];
    $grade = trim($_POST['grade']);
    $feedback = trim($_POST['feedback']);
    $new_status = 'graded'; 
    if(empty($grade) && empty($feedback)) { // If both are empty, maybe revert to 'submitted' or 'pending_grading'
        // $new_status = 'submitted'; // Or 'pending_grading'
        // For simplicity, we always set to 'graded' if form is submitted. Could be more nuanced.
    }


    $stmt_grade = $conn->prepare("UPDATE submissions SET grade = ?, feedback = ?, status = ? WHERE id = ? AND assignment_id = ?");
    $stmt_grade->bind_param("sssii", $grade, $feedback, $new_status, $submission_id_to_grade, $assignment_id);
    if ($stmt_grade->execute()) {
        $_SESSION['message'] = "Đã cập nhật điểm và phản hồi cho bài nộp.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Lỗi khi cập nhật: " . $stmt_grade->error;
        $_SESSION['message_type'] = "danger";
    }
    $stmt_grade->close();
    // Refresh page to see changes or use AJAX for a smoother experience
    redirect("view_submissions.php?assignment_id=" . $assignment_id);
    exit;
}


// Fetch all students in the class and their submission status for this assignment
$submissions_data = []; // Changed variable name to avoid conflict
$stmt_students = $conn->prepare("
    SELECT u.id as student_id, u.full_name, u.email, u.profile_picture,
           s.id as submission_id, s.submission_text, s.file_path as submission_file, s.submitted_at, s.status, s.grade, s.feedback
    FROM users u
    JOIN enrollments e ON u.id = e.user_id
    LEFT JOIN submissions s ON u.id = s.student_id AND s.assignment_id = ?
    WHERE e.class_id = ? AND u.role = 'student'
    ORDER BY u.full_name ASC
");
$stmt_students->bind_param("ii", $assignment_id, $assignment['class_id']);
$stmt_students->execute();
$result_students = $stmt_students->get_result();
while ($row = $result_students->fetch_assoc()) {
    $submissions_data[] = $row;
}
$stmt_students->close();

?>
<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
    <div>
        <h3 class="mb-1">Bài nộp cho: <?php echo htmlspecialchars($assignment['title']); ?></h3>
        <p class="mb-0"><small>Lớp: <?php echo htmlspecialchars($assignment['class_name']); ?> | Hạn nộp: <?php echo date("d/m/Y H:i", strtotime($assignment['due_date'])); ?></small></p>
    </div>
    <a href="class_view.php?id=<?php echo $assignment['class_id']; ?>&tab=assignments" class="btn btn-outline-secondary mt-2 mt-md-0"><i class="bi bi-arrow-left-circle me-1"></i>Quay lại</a>
</div>


<?php if (empty($submissions_data)): ?>
    <div class="alert alert-info">Chưa có học sinh nào trong lớp hoặc chưa có bài nộp nào cho bài tập này.</div>
<?php else: ?>
    <div class="accordion shadow-sm" id="submissionsAccordion">
        <?php foreach ($submissions_data as $index => $sub): ?>
        <div class="accordion-item">
            <h2 class="accordion-header" id="heading-<?php echo $sub['student_id']; ?>">
                <button class="accordion-button <?php echo ($index != 0 && !isset($_GET['open_student']) ) || (isset($_GET['open_student']) && $_GET['open_student'] != $sub['student_id']) ? 'collapsed' : ''; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo $sub['student_id']; ?>" aria-expanded="<?php echo ($index == 0 && !isset($_GET['open_student'])) || (isset($_GET['open_student']) && $_GET['open_student'] == $sub['student_id']) ? 'true' : 'false'; ?>" aria-controls="collapse-<?php echo $sub['student_id']; ?>">
                    <img src="uploads/profile_pictures/<?php echo htmlspecialchars($sub['profile_picture'] ?: 'default.png'); ?>" alt="<?php echo htmlspecialchars($sub['full_name']); ?>" class="profile-picture-sm me-2" onerror="this.onerror=null;this.src='uploads/profile_pictures/default.png';">
                    <?php echo htmlspecialchars($sub['full_name']); ?>
                    <small class="text-muted ms-1">(<?php echo htmlspecialchars($sub['email']); ?>)</small>
                    <span class="ms-auto">
                    <?php if ($sub['submission_id']): ?>
                        <span class="badge bg-<?php 
                            if ($sub['status'] == 'graded') echo 'success'; 
                            elseif ($sub['status'] == 'late') echo 'warning text-dark'; 
                            elseif ($sub['status'] == 'submitted' || $sub['status'] == 'pending_grading') echo 'info text-dark';
                            else echo 'secondary'; // Default
                        ?>">
                            <?php echo htmlspecialchars(ucfirst($sub['status'])); ?>
                            <?php if ($sub['submitted_at']) echo ' - ' . date("d/m/y H:i", strtotime($sub['submitted_at'])); ?>
                        </span>
                        <?php if ($sub['grade']): ?>
                            <span class="badge bg-primary ms-1">Điểm: <?php echo htmlspecialchars($sub['grade']); ?></span>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="badge bg-danger">Chưa nộp</span>
                    <?php endif; ?>
                    </span>
                </button>
            </h2>
            <div id="collapse-<?php echo $sub['student_id']; ?>" class="accordion-collapse collapse <?php echo ($index == 0 && !isset($_GET['open_student'])) || (isset($_GET['open_student']) && $_GET['open_student'] == $sub['student_id']) ? 'show' : ''; ?>" aria-labelledby="heading-<?php echo $sub['student_id']; ?>" data-bs-parent="#submissionsAccordion">
                <div class="accordion-body">
                    <?php if ($sub['submission_id']): ?>
                        <h5>Nội dung nộp:</h5>
                        <?php if ($sub['submission_text']): ?>
                            <div class="p-2 bg-light border rounded mb-2 submission-text-display">
                                <?php echo nl2br(htmlspecialchars($sub['submission_text'])); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($sub['submission_file']): ?>
                            <p><strong>Tệp đính kèm:</strong> <a href="uploads/submission_files/<?php echo htmlspecialchars($sub['submission_file']); ?>" target="_blank" download><i class="bi bi-download me-1"></i><?php echo htmlspecialchars($sub['submission_file']); ?></a></p>
                        <?php endif; ?>
                         <?php if (empty($sub['submission_text']) && empty($sub['submission_file'])): ?>
                            <p class="text-muted">Không có nội dung hoặc tệp nào được nộp.</p>
                        <?php endif; ?>

                        <hr>
                        <h5>Chấm điểm và Phản hồi:</h5>
                        <form action="view_submissions.php?assignment_id=<?php echo $assignment_id; ?>&open_student=<?php echo $sub['student_id']; ?>#heading-<?php echo $sub['student_id']; ?>" method="POST">
                            <input type="hidden" name="submission_id" value="<?php echo $sub['submission_id']; ?>">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="grade-<?php echo $sub['student_id']; ?>" class="form-label">Điểm</label>
                                    <input type="text" class="form-control" id="grade-<?php echo $sub['student_id']; ?>" name="grade" value="<?php echo htmlspecialchars($sub['grade'] ?? ''); ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="feedback-<?php echo $sub['student_id']; ?>" class="form-label">Phản hồi (Ghi chú cho học sinh)</label>
                                <textarea class="form-control" id="feedback-<?php echo $sub['student_id']; ?>" name="feedback" rows="3"><?php echo htmlspecialchars($sub['feedback'] ?? ''); ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-save me-1"></i>Lưu điểm & Phản hồi</button>
                        </form>
                    <?php else: ?>
                        <p class="text-muted">Học sinh này chưa nộp bài.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>