<?php
require_once 'includes/header.php';
if (!isLoggedIn() || !isAdmin()) {
    $_SESSION['message'] = "Bạn không có quyền truy cập trang này.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}

$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
if ($class_id <= 0) {
    $_SESSION['message'] = "ID lớp học không hợp lệ để tạo bài tập.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}

// Verify teacher owns this class
$stmt_verify = $conn->prepare("SELECT class_name FROM classes WHERE id = ? AND teacher_id = ?");
$stmt_verify->bind_param("ii", $class_id, $_SESSION['user_id']);
$stmt_verify->execute();
$result_verify = $stmt_verify->get_result();
if ($result_verify->num_rows == 0) {
    $_SESSION['message'] = "Bạn không phải là giáo viên của lớp này hoặc lớp không tồn tại.";
    $_SESSION['message_type'] = "danger";
    redirect('dashboard.php');
}
$class_info = $result_verify->fetch_assoc();
$stmt_verify->close();


$title = $description = $due_date = '';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $due_date = trim($_POST['due_date']);
    $file_path = null;

    if (empty($title)) $errors['title'] = "Tiêu đề bài tập là bắt buộc.";
    if (empty($due_date)) {
        $errors['due_date'] = "Thời hạn nộp bài là bắt buộc.";
    } else {
        // Basic validation for due date (e.g., must be in the future)
        if (strtotime($due_date) <= time()) {
            // $errors['due_date'] = "Thời hạn nộp bài phải là một thời điểm trong tương lai.";
            // Allow same day, but not past
        }
    }


    // File upload handling
    if (isset($_FILES['assignment_file']) && $_FILES['assignment_file']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/assignment_files/';
        if (!is_dir($upload_dir)) { // Check if dir exists, if not, try to create
            if (!mkdir($upload_dir, 0777, true) && !is_dir($upload_dir)) { // Check again after trying to create
                 $errors['file'] = "Không thể tạo thư mục tải lên: " . $upload_dir;
            }
        }
        
        if (empty($errors['file'])) { // Proceed if no directory creation error
            $file_name = time() . '_' . preg_replace("/[^a-zA-Z0-9.\-_]/", "_", basename($_FILES['assignment_file']['name']));
            $target_file = $upload_dir . $file_name;
            $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

            if ($_FILES['assignment_file']['size'] > 5000000) { // 5MB
                $errors['file'] = "Xin lỗi, tệp của bạn quá lớn (tối đa 5MB).";
            }
            $allowed_types = ['pdf', 'doc', 'docx', 'txt', 'jpg', 'jpeg', 'png', 'zip', 'ppt', 'pptx', 'xls', 'xlsx'];
            if (!in_array($file_type, $allowed_types)) {
                $errors['file'] = "Xin lỗi, chỉ cho phép các tệp: " . implode(', ', $allowed_types) . ".";
            }

            if (empty($errors['file'])) {
                if (move_uploaded_file($_FILES['assignment_file']['tmp_name'], $target_file)) {
                    $file_path = $file_name;
                } else {
                    $errors['file'] = "Lỗi khi tải tệp lên. Kiểm tra quyền ghi của thư mục 'uploads/assignment_files/'. Error code: ".$_FILES['assignment_file']['error'];
                }
            }
        }
    } elseif (isset($_FILES['assignment_file']) && $_FILES['assignment_file']['error'] != UPLOAD_ERR_NO_FILE) {
        // Handle other upload errors
        $errors['file'] = "Lỗi tải tệp lên. Mã lỗi: " . $_FILES['assignment_file']['error'];
    }


    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO assignments (class_id, title, description, due_date, file_path) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $class_id, $title, $description, $due_date, $file_path);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Bài tập \"".htmlspecialchars($title)."\" đã được tạo thành công.";
            $_SESSION['message_type'] = "success";
            redirect("class_view.php?id={$class_id}&tab=assignments");
        } else {
            $errors['db_error'] = "Lỗi khi tạo bài tập: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h3 class="mb-0">Tạo bài tập mới</h3>
                <p class="mb-0"><small>Cho lớp: <?php echo htmlspecialchars($class_info['class_name']); ?></small></p>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($errors['db_error'])): ?>
                    <div class="alert alert-danger"><?php echo $errors['db_error']; ?></div>
                <?php endif; ?>
                 <?php if (!empty($errors['file'])): ?>
                    <div class="alert alert-danger"><?php echo $errors['file']; ?></div>
                <?php endif; ?>

                <form action="create_assignment.php?class_id=<?php echo $class_id; ?>" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="title" class="form-label">Tiêu đề bài tập <span class="text-danger">*</span></label>
                        <input type="text" class="form-control <?php echo isset($errors['title']) ? 'is-invalid' : ''; ?>" id="title" name="title" value="<?php echo htmlspecialchars($title); ?>" required autofocus>
                        <?php if (isset($errors['title'])): ?><div class="invalid-feedback"><?php echo $errors['title']; ?></div><?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Mô tả chi tiết</label>
                        <textarea class="form-control" id="description" name="description" rows="5"><?php echo htmlspecialchars($description); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="due_date" class="form-label">Thời hạn nộp bài <span class="text-danger">*</span></label>
                        <input type="datetime-local" class="form-control <?php echo isset($errors['due_date']) ? 'is-invalid' : ''; ?>" id="due_date" name="due_date" value="<?php echo htmlspecialchars($due_date); ?>" required>
                        <?php if (isset($errors['due_date'])): ?><div class="invalid-feedback"><?php echo $errors['due_date']; ?></div><?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="assignment_file" class="form-label">Tệp đính kèm (tùy chọn)</label>
                        <input type="file" class="form-control" id="assignment_file" name="assignment_file">
                        <div class="form-text">Tối đa 5MB. Định dạng: PDF, DOC(X), TXT, JPG, PNG, ZIP, PPT(X), XLS(X).</div>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-circle me-2"></i>Tạo bài tập</button>
                    <a href="class_view.php?id=<?php echo $class_id; ?>&tab=assignments" class="btn btn-secondary">Hủy</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>