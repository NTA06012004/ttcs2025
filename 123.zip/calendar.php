<?php
require_once 'includes/header.php';
if (!isLoggedIn()) { redirect('login.php'); }

$user_id = $_SESSION['user_id'];

// Fetch assignments user is involved in (either as teacher or student)
$events = [];
$start_date_range = date('Y-m-d', strtotime('-2 week')); // Show events from 2 weeks ago
$end_date_range = date('Y-m-d', strtotime('+4 week'));   // Show events up to 4 weeks in future

if ($_SESSION['role'] == 'teacher') {
    $stmt = $conn->prepare("
        SELECT a.title, a.due_date, c.class_name, a.id as assignment_id, c.id as class_id
        FROM assignments a
        JOIN classes c ON a.class_id = c.id
        WHERE c.teacher_id = ? AND a.due_date BETWEEN ? AND ?
        ORDER BY a.due_date ASC
    ");
    $stmt->bind_param("iss", $user_id, $start_date_range, $end_date_range);
} else { // student
    $stmt = $conn->prepare("
        SELECT a.title, a.due_date, c.class_name, a.id as assignment_id, c.id as class_id,
               s.id as submission_id, s.status as submission_status
        FROM assignments a
        JOIN classes c ON a.class_id = c.id
        JOIN enrollments e ON c.id = e.class_id
        LEFT JOIN submissions s ON a.id = s.assignment_id AND s.student_id = e.user_id
        WHERE e.user_id = ? AND a.due_date BETWEEN ? AND ?
        ORDER BY a.due_date ASC
    ");
    $stmt->bind_param("iss", $user_id, $start_date_range, $end_date_range);
}
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $event_item = [
        'title' => $row['title'] . ' (' . $row['class_name'] . ')',
        'date' => date("Y-m-d", strtotime($row['due_date'])),
        'time' => date("H:i", strtotime($row['due_date'])),
        'description' => 'Hạn nộp bài tập.',
        'url' => 'class_view.php?id=' . $row['class_id'] . '&tab=assignments#assignment-' . $row['assignment_id'],
        'is_past' => strtotime($row['due_date']) < time(),
        'is_submitted' => ($_SESSION['role'] == 'student' && !empty($row['submission_id'])) // For students
    ];
    if ($_SESSION['role'] == 'student') {
        $event_item['status_class'] = $event_item['is_submitted'] ? 'text-success' : ($event_item['is_past'] ? 'text-danger' : 'text-primary');
        if ($event_item['is_submitted']) {
            $event_item['title'] .= ' <i class="bi bi-check-circle-fill text-success" title="Đã nộp"></i>';
        } elseif ($event_item['is_past']) {
             $event_item['title'] .= ' <i class="bi bi-exclamation-triangle-fill text-danger" title="Quá hạn"></i>';
        }
    } else { // Teacher
         $event_item['status_class'] = $event_item['is_past'] ? 'text-secondary' : 'text-primary';
    }
    $events[] = $event_item;
}
$stmt->close();

// You could add personal events from an `events` table here too

// Group events by date for display
$grouped_events = [];
foreach ($events as $event) {
    $grouped_events[$event['date']][] = $event;
}
ksort($grouped_events); // Sort by date
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2><i class="bi bi-calendar3 me-2"></i>Lịch của bạn</h2>
    <!-- Add buttons for Day/Week/Month view if implementing a JS calendar -->
</div>

<?php if (empty($grouped_events)): ?>
    <div class="alert alert-info">Không có sự kiện (hạn nộp bài tập) nào trong khoảng thời gian này.</div>
<?php else: ?>
    <p class="text-muted">Hiển thị các hạn nộp bài tập. (Để có lịch đầy đủ, cần tích hợp thư viện JavaScript Calendar như FullCalendar).</p>
    <?php foreach ($grouped_events as $date => $date_events):
        $is_today = (date("Y-m-d") == $date);
        $is_past_date = (strtotime($date) < strtotime(date("Y-m-d")));
    ?>
        <div class="card mb-3 shadow-sm <?php echo $is_today ? 'border-primary' : ($is_past_date ? 'border-light' : ''); ?>">
            <div class="card-header <?php echo $is_today ? 'bg-primary text-white' : ($is_past_date ? 'bg-light text-muted' : 'bg-light'); ?>">
                <strong><?php echo date("l, d F Y", strtotime($date)); ?> <?php if($is_today) echo "(Hôm nay)"; ?></strong>
            </div>
            <ul class="list-group list-group-flush">
                <?php foreach ($date_events as $event): ?>
                <li class="list-group-item <?php if ($event['is_past'] && $_SESSION['role'] == 'student' && !$event['is_submitted']) echo 'list-group-item-danger'; elseif ($_SESSION['role'] == 'student' && $event['is_submitted']) echo 'list-group-item-success '; ?>">
                    <div class="d-flex w-100 justify-content-between align-items-center">
                        <h5 class="mb-1 <?php echo $event['status_class']; ?>"><a href="<?php echo htmlspecialchars($event['url']); ?>" class="text-decoration-none <?php echo $event['status_class']; ?>"><?php echo $event['title']; // Title already has icon for student ?></a></h5>
                        <span class="badge bg-secondary rounded-pill"><?php echo htmlspecialchars($event['time']); ?></span>
                    </div>
                    <p class="mb-1 text-muted"><?php echo htmlspecialchars($event['description']); ?></p>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
<p class="mt-4 text-center"><em>Gợi ý: Để có trải nghiệm lịch tốt hơn, cân nhắc tích hợp Google Calendar hoặc một thư viện JavaScript như FullCalendar.</em></p>

<?php require_once 'includes/footer.php'; ?>